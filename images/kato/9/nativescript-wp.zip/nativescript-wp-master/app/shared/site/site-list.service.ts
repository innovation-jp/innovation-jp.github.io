import { Injectable } from "@angular/core";
import { Http, Headers, Response } from "@angular/http";
import { Observable } from "rxjs/Rx";
import "rxjs/add/operator/do";
import "rxjs/add/operator/map";

import { Site } from "./site";
import { Config } from "../config";

@Injectable()
export class SiteListService {

    constructor(private http: Http) {
    }

    load() {
        let headers = new Headers();
        headers.append("Authorization", "Bearer " + Config.accessToken);

        return this.http.get(Config.apiUrl + "/me/sites", {
            headers: headers
        })
            .map(res => {

                return res.json();
            })
            .map(data => {
                let siteList = [];
                data.sites.forEach((site) => {
                    siteList.push(new Site(
                        site.ID,
                        site.name,
                        site.description,
                        site.icon.img
                    ));
                });
                return siteList;
            })
            .catch(this.handleErrors);
    }


    handleErrors(error: Response) {
        console.log(JSON.stringify(error.json()));
        return Observable.throw(error);
    }
}