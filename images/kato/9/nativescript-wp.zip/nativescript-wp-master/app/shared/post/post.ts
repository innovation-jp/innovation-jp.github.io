export class Post {

    constructor(public id: string,
                public author: object,
                public date: string,
                public modified: string,
                public title: string,
                public url: string,
                public content: string,
                public featured_image: string,
                ) {
    }
}
