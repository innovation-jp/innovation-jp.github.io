import { Injectable } from "@angular/core";
import { Http, Headers, Response, RequestOptions, RequestOptionsArgs } from "@angular/http";
import { Observable } from "rxjs/Rx";
import { Config } from "../config";
import "rxjs/add/operator/do";
import "rxjs/add/operator/map";
import "rxjs/add/operator/mergeMap";
import * as bghttp from "nativescript-background-http";

@Injectable()
export class PostService {

    constructor(private http: Http) {
    }


    /**
     * mediaと投稿の追加
     * @param {string} siteId
     * @param {string} title
     * @param {string} filePath
     */
    create(siteId: string, title: string, filePath: string) {

        console.log('投稿の開始');

        return this
            .createMedia(siteId, filePath)
            .flatMap(value => {
                let media = JSON.parse(value.data).media[0];
                return this.createPost(siteId, title, media.ID, media.URL);
            })
            .catch(this.handleErrors);
    }


    /**
     * mediaを追加
     * @param {string} siteId
     * @param {string} filePath
     * @returns {any}
     */
    createMedia(siteId: string, filePath: string) {

        let request = {
            url        : Config.apiUrl + "/sites/" + siteId + "/media/new",
            method     : "POST",
            headers    : {
                "Authorization": "Bearer " + Config.accessToken,
                "Content-Type" : "application/octet-stream",
            },
            description: "mediaの追加"
        };

        let params = [
            {name: "media[]", filename: filePath, mimeType: 'image/jpeg'}
        ];

        let session = bghttp.session("image-upload");
        let task: bghttp.Task = session.multipartUpload(params, request);

        return Observable.create(observer => {
            task.on('error', e => {
                throw new Error('[' + e.eventName + ']画像のアップに失敗しました')
            });
            task.on('responded', e => observer.next(e));
        });
    }


    /**
     * 投稿を追加
     * @param {string} siteId
     * @param {string} title
     * @param {string} mediaId
     * @param {string} mediaUrl
     */
    createPost(siteId: string, title: string, mediaId: string, mediaUrl: string) {

        console.log(siteId + "ID:" + mediaId + title + "/" + mediaUrl);

        let params = {
            "title"         : title,
            "content"       : '<img class="alignnone size-full wp-image-' + mediaId + '" src="' + mediaUrl + '" />',
            "status"        : "publish",
            "author"        : Config.author,
            "featured_image": mediaUrl
        };

        let headers = new Headers();
        headers.append("Authorization", "Bearer " + Config.accessToken);

        return this.http
            .post(Config.apiUrl + "/sites/" + siteId + "/posts/new", params, {
                headers: headers,
            })
            .map(res => {
                console.log('ファイルをアップしました')
                return res.json();
            })
            .catch(this.handleErrors);
    }


    /**
     * エラー handle
     * @param {Response} error
     * @returns {ErrorObservable}
     */
    handleErrors(error: Response) {
        console.log(JSON.stringify(error.json()));
        return Observable.throw(error);
    }
}