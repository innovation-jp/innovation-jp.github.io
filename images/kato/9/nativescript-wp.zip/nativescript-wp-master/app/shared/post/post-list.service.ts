import { Injectable } from "@angular/core";
import { Http, Headers, Response } from "@angular/http";
import { Observable } from "rxjs/Rx";
import "rxjs/add/operator/do";
import "rxjs/add/operator/map";

import { Post } from "./post";
import { Config } from "../config";

@Injectable()
export class PostListService {

    constructor(private http: Http) {
    }

    load(siteId: String) {
        let headers = new Headers();
        headers.append("Authorization", "Bearer " + Config.accessToken);

        return this.http.get(Config.apiUrl + "/sites/" + siteId + "/posts", {
            headers: headers
        })
            .map(res => {
                return res.json();
            })
            .map(data => {
                let postList = [];
                data.posts.forEach((post) => {
                    postList.push(new Post(
                        post.ID,
                        post.author,
                        post.date,
                        post.modified,
                        post.title,
                        post.url,
                        post.content,
                        post.featured_image
                    ));
                });
                return postList;
            })
            .catch(this.handleErrors);
    }


    handleErrors(error: Response) {
        console.log(JSON.stringify(error.json()));
        return Observable.throw(error);
    }
}