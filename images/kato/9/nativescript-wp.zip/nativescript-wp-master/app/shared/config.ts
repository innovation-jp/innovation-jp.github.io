export class Config {

  static apiUrl = "https://public-api.wordpress.com/rest/v1.1";
  static accessToken = "";
  static author = "";
}