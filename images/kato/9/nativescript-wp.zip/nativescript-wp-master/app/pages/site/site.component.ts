import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";

import { Router, NavigationExtras } from "@angular/router";
import { Site } from "../../shared/site/site";
import { SiteListService } from "../../shared/site/site-list.service";

//import * as SocialShare from "nativescript-social-share";


import { ItemEventData } from "ui/list-view";


@Component({
    selector   : "list",
    templateUrl: "pages/site/site.html",
    styleUrls  : ["pages/site/site-common.css", "pages/site/site.css"],
    providers  : [SiteListService]
})

export class SiteComponent implements OnInit {
    siteList: Array<Site> = [];

    isLoading  = false;
    listLoaded = false;
    constructor(private router: Router,
                private siteListService: SiteListService) {

    }

    onItemLoading(args: ItemEventData) {
        if (args.ios) {
            args.ios.accessoryType = 1; // UITableViewCellAccessoryDisclosureIndicator
        }
    }

    ngOnInit() {
         this.isLoading = true;
         this.siteListService.load()
             .subscribe(loadedSites => {
                 loadedSites.forEach((sites) => {
                     this.siteList.unshift(sites);
                 });
                 this.isLoading  = false;
                 this.listLoaded = true;
             });

         //this.router.navigate(["/post-create", "135019491"]);
    }

    onSiteTap(item) {

        let navigationExtras: NavigationExtras = {
            queryParams: <Object>item
        };

        this.router.navigate(["/post", item.id], navigationExtras);
    }

}