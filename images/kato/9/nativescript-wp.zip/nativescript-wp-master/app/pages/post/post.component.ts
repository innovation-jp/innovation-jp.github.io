import * as application from "application";
import { Component, OnInit,  } from "@angular/core";
import { Router, ActivatedRoute, NavigationExtras } from "@angular/router";
import { Frame } from "ui/frame";

import { Post } from "../../shared/post/post";
import { PostListService } from "../../shared/post/post-list.service";


@Component({
    selector   : "list",
    templateUrl: "pages/post/post.html",
    styleUrls  : ["pages/post/post-common.css", "pages/post/post.css"],
    providers  : [PostListService]
})


export class PostComponent implements OnInit {
    postList: Array<Post> = [];
    isLoading             = false;
    listLoaded            = false;
    site                  = {};

    /**
     * constructor
     * @param {Frame} frame
     * @param {Router} router
     * @param {ActivatedRoute} route
     * @param {PostListService} postListService
     */
    constructor(private frame: Frame,
                private router: Router,
                private route: ActivatedRoute,
                private postListService: PostListService) {
    }
    

    ngOnInit() {
        this.route.queryParams.subscribe(site => {
            this.site = site
            this.onLoad();
        });
    }


    onLoad() {
        this.isLoading = true;
        this.postListService.load(this.site["id"])
            .subscribe(loadedPosts => {
                loadedPosts.forEach((postObject) => {
                    this.postList.unshift(postObject);
                });
                this.isLoading  = false;
                this.listLoaded = true;
            });
    }


    /**
     * 戻るをタップ
     */
    onNavBtnTap() {
        if (application.android) {
            this.frame.goBack();
        }
    }


    /**
     * 投稿をタップ胃
     * @param item
     */
    onCreateTap() {
        let navigationExtras: NavigationExtras = {
            queryParams: <Object>this.site
        };

        this.router.navigate(["/post-create", this.site['id']], navigationExtras);
    }

}