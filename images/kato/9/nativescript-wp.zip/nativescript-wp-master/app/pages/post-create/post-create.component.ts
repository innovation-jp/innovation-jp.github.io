import { Component, OnInit, ChangeDetectorRef } from "@angular/core";
import { LoadingIndicator } from "nativescript-loading-indicator";
import { PostService } from "../../shared/post/post.service";
import { RouterExtensions } from "nativescript-angular";
import { ActivatedRoute } from "@angular/router";
import * as imagepicker from "nativescript-imagepicker";

@Component({
    selector   : "list",
    templateUrl: "pages/post-create/post-create.html",
    styleUrls  : ["pages/post-create/post-create-common.css", "pages/post-create/post-create.css"],
    providers  : [PostService]
})

/**
 * 新規投稿画面
 */
export class PostCreateComponent implements OnInit {

    isLoading  = false;
    listLoaded = false;
    site       = {};
    title      = "";
    image_path = null;
    image = null;
    loader     = null;


    /**
     * constructor
     * @param {PostService} postService
     * @param {RouterExtensions} routerExtensions
     */
    constructor(private postService: PostService,
                private routerExtensions: RouterExtensions,
                private route: ActivatedRoute,
                private _changeDetectionRef: ChangeDetectorRef) {
        this.loader = new LoadingIndicator();
    }


    /**
     * ngOnInit
     */
    ngOnInit() {
        this.route.queryParams.subscribe(site => {
            this.site = site
        });
    }


    /**
     * 戻るをタップ
     */
    onNavBtnTap() {
        this.routerExtensions.backToPreviousPage();
    }


    /**
     * 新規投稿をタップ
     */
    onPostTap() {

        this.title = "テストタイトル"

        if (!this.title) {
            alert("タイトルを入力して下さい");
        }
        else if (!this.image_path) {
            alert("画像を選択して下さい")
        }
        else {
            this.showLoader();
            this.postService
                .create(this.site['id'], this.title, this.image_path)
                .subscribe(loadedPost => {
                    this.hideLoader();
                    this.onNavBtnTap()

                });
        }
    }


    /**
     * 画像選択をタップ
     */
    onSelectSingleTap() {
        let context = imagepicker.create({
            mode: "single"
        });
        this.startSelection(context);
    }


    /**
     * 画像選択開始
     * @param context
     */
    startSelection(context) {
        let _that = this;
        context
            .authorize()
            .then(() => {
                _that.image_path = null;
                return context.present();
            })
            .then((selection) => {

                if (selection.length == 1) {
                    _that.image_path = selection[0].fileUri.replace(/file:\/\//, '');
                    console.log("Selection done:");
                }
                else {
                    _that.image_path = null;
                    _that.image = null;
                }

                _that._changeDetectionRef.detectChanges();
            })
            .catch(function (e) {
                console.log(e);
            });
    }


    /**
     * ローディングの表示
     */
    showLoader() {
        // optional options
        // android and ios have some platform specific options
        let options = {
            message : '投稿中...',
            progress: 0.65,
            android : {
                indeterminate        : true,
                cancelable           : false,
                max                  : 100,
                progressNumberFormat : "%1d/%2d",
                progressPercentFormat: 0.53,
                progressStyle        : 1,
                secondaryProgress    : 1
            },
            ios     : {
                //details        : "新規投稿をしています",
                margin         : 10,
                dimBackground  : true,
                color          : "#4B9ED6", // color of indicator and labels
                // background box around indicator
                // hideBezel will override this if true
                backgroundColor: "yellow",
                hideBezel      : true, // default false, can hide the surrounding bezel
                //view: UIView, // Target view to show on top of (Defaults to entire window)
                //mode: // see iOS specific options below
            }
        };

        this.loader.show(options);
    }


    /**
     * ローディングの非表示
     */
    hideLoader() {
        this.loader.hide();
    }


}