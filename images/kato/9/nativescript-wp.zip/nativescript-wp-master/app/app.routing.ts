import { NgModule } from "@angular/core";
import { NativeScriptRouterModule } from "nativescript-angular/router";
import { Routes } from "@angular/router";


import { SiteComponent } from "./pages/site/site.component";
import { PostComponent } from "./pages/post/post.component";
import { PostCreateComponent } from "./pages/post-create/post-create.component";


const routes: Routes = [
    {path: "", redirectTo: "/site", pathMatch: "full"},
    {path: "site", component: SiteComponent},
    {path: "post/:site", component: PostComponent},
    {path: "post-create/:site", component: PostCreateComponent},

];

@NgModule({
    imports: [NativeScriptRouterModule.forRoot(routes)],
    exports: [NativeScriptRouterModule],
})
export class AppRoutingModule {
}


export const navigatableComponents = [
    SiteComponent,
    PostComponent,
    PostCreateComponent,
];

